const app = {
    data: {
        products: []
    },

    init: function () {
        this.loadData();
        this.renderList();
    },

    navigate: function (viewId) {
        document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
        document.getElementById('view-' + viewId).classList.add('active');

        if (viewId === 'capture') {
            this.resetForm();
        } else if (viewId === 'home') {
            this.renderList();
        }
    },

    handleImage: function (input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const img = document.getElementById('img-preview');
                img.src = e.target.result;
                img.style.display = 'block';
                document.getElementById('camera-placeholder').style.display = 'none';
            }
            reader.readAsDataURL(input.files[0]);
        }
    },

    generateBarcode: function () {
        const random = Math.floor(100000 + Math.random() * 900000).toString();
        document.getElementById('inp-barcode').value = random;
    },

    adjustQty: function (id, delta) {
        const el = document.getElementById(id);
        let val = parseInt(el.value) || 0;
        val += delta;
        if (val < 1) val = 1;
        el.value = val;
    },

    saveProduct: function () {
        const barcode = document.getElementById('inp-barcode').value.trim();
        const name = document.getElementById('inp-name').value.trim();
        const price = document.getElementById('inp-price').value.trim();
        const qty = parseInt(document.getElementById('inp-qty').value) || 1;
        const imgSrc = document.getElementById('img-preview').src;

        if (!barcode || !name) {
            alert("Código y Nombre son obligatorios");
            return;
        }

        const product = {
            id: Date.now().toString(),
            barcode,
            name,
            price: parseFloat(price) || 0,
            qty,
            image: imgSrc.startsWith('data:') ? imgSrc : null
        };

        this.data.products.push(product);
        this.saveData();
        this.navigate('home');
    },

    deleteProduct: function (id) {
        if (confirm("¿Eliminar producto?")) {
            this.data.products = this.data.products.filter(p => p.id !== id);
            this.saveData();
            this.renderList();
        }
    },

    updateProductQty: function (id, newQty) {
        const p = this.data.products.find(p => p.id === id);
        if (p) {
            p.qty = parseInt(newQty);
            this.saveData();
        }
    },

    renderList: function () {
        const container = document.getElementById('product-list');
        if (this.data.products.length === 0) {
            container.innerHTML = '<div style="text-align: center; padding: 40px; color: #888;">No hay productos.<br>Toca + para agregar.</div>';
            return;
        }

        container.innerHTML = this.data.products.map(p => `
            <div class="product-item">
                <img src="${p.image || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1MCIgaGVpZ2h0PSI1MCI+PHJlY3Qgd2lkdGg9IjUwIiBoZWlnaHQ9IjUwIiBmaWxsPSIjZWVlIi8+PC9zdmc+'}" class="product-thumb">
                <div class="product-info">
                    <div class="product-name">${p.name}</div>
                    <div class="product-meta">${p.barcode}</div>
                </div>
                <div class="qty-control">
                    <div class="qty-btn" onclick="app.updateProductQty('${p.id}', ${p.qty - 1}); app.renderList()">-</div>
                    <span style="width: 30px; text-align: center;">${p.qty}</span>
                    <div class="qty-btn" onclick="app.updateProductQty('${p.id}', ${p.qty + 1}); app.renderList()">+</div>
                </div>
                <button class="btn btn-outline" style="width: auto; margin: 0; padding: 4px 8px; border: none; color: #b00020;" onclick="app.deleteProduct('${p.id}')">🗑️</button>
            </div>
        `).join('');
    },

    resetForm: function () {
        document.getElementById('inp-barcode').value = '';
        document.getElementById('inp-name').value = '';
        document.getElementById('inp-price').value = '';
        document.getElementById('inp-qty').value = '1';
        document.getElementById('img-preview').src = '';
        document.getElementById('img-preview').style.display = 'none';
        document.getElementById('camera-placeholder').style.display = 'block';
        document.getElementById('inp-camera').value = '';
    },

    saveData: function () {
        try {
            localStorage.setItem('inventory_setup_data', JSON.stringify(this.data));
        } catch (e) {
            alert("Error guardando datos (posiblemente memoria llena por imágenes). Intenta tomar fotos de menor resolución.");
        }
    },

    loadData: function () {
        const stored = localStorage.getItem('inventory_setup_data');
        if (stored) {
            this.data = JSON.parse(stored);
        }
    },

    clearData: function () {
        if (confirm("¿BORRAR TODO? Esto no se puede deshacer.")) {
            this.data.products = [];
            this.saveData();
            this.renderList();
        }
    },

    generatePDF: async function () {
        if (this.data.products.length === 0) {
            alert("No hay productos para generar.");
            return;
        }

        document.getElementById('loading').style.display = 'flex';

        // Defer to allow UI update
        setTimeout(async () => {
            try {
                await pdfGenerator.generate(this.data.products);
            } catch (e) {
                alert("Error generando PDF: " + e.message);
                console.error(e);
            } finally {
                document.getElementById('loading').style.display = 'none';
            }
        }, 100);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    app.init();
});
